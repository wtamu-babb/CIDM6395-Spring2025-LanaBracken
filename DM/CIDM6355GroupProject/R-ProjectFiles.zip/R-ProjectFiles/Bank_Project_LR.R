# define and choose the dataset 
bankdatafull <- read.csv(choose.files(), header = T)
#bankdatafull_ <- read.csv(choose.files(), header = T)
#check structure of datasets
str(bankdatafull)
#need to convert char to factor
bankdatafull[sapply(bankdatafull, is.character)] <- lapply(bankdatafull [sapply(bankdatafull, is.character)], as.factor)
#view structure again, verify factor instead of character 
str(bankdatafull)
summary(bankdatafull)
#attach the training dataset for ease of writing and maintaining code
attach(bankdatafull)
#set random seed to make the sampling reproducaible
set.seed(123)
smp_size<-floor(.9 * nrow(bankdatafull))
train_ind<-sample(seq_len(nrow(bankdatafull)), size=smp_size)
train <-bankdatafull[train_ind, ]
test <- bankdatafull[-train_ind, ]
#check the ratio of train set
nrow(train)/nrow(bankdatafull)
# install and load the required libraries
install.packages("e1071")
install.packages("caret")
install.packages("dplyr")
install.packages("reshape2")
# installing library dplyr,caret,dplyr,reshape2
library("e1071")
library("caret")
library("dplyr")
library("reshape2")


# building a logistic regression model using the train set
bankdatafullLR <- glm(y ~. , family = "binomial", bankdatafull)

#view the logistic regression model
summary(bankdatafullLR)

# apply the model to the test set; probabilities are generated 
BankLP <- predict(bankdatafullLR, test, type = "response")

#convert probabilities to prediction class and then convert it to a factor
Bank_LRP<-as.factor(ifelse(BankLP> 0.5, "yes", "no"))

#view the new logistic regression model with > 0.5
summary(Bank_LRP)

# confusion matrix for LR
# generating a sample table for confusion matrix using a tble function
table(Bank_LRP, test[["y"]])

# using confusion matrix function as an alternatively to get more details
# checking  for the type of both Bank_LRP and y before running the confusion matrix
# Because confusionMatrix function requires factors with the same level

typeof(Bank_LRP)
typeof(test[["y"]])

# running the confusion Matrix since the attribute has the same factors level

BankLRP_class<-as.factor(Bank_LRP)

# building the confusion Matrix 
confusionMatrix(BankLRP_class, as.factor(test[["y"]]))
confusionMatrix(BankLRP_class, as.factor(test[["y"]]), positive="yes")
