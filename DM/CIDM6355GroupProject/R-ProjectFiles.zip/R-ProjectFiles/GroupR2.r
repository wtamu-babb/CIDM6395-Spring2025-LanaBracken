#define and import training and prediction datasets
FullBank<-read.csv(file.choose(), sep=",", header=T)
#check structure of datasets
str(FullBank)
#need to convert char to factor
FullBank[sapply(FullBank, is.character)] <- lapply(FullBank[sapply(FullBank, is.character)], as.factor)
#view structure again, verify factor instead of chr
str(FullBank)
#normalize the numerical attributes - helps neural network
#normalize the numerical attributes to the range 0-1
FullBank$age<-(FullBank$age-min(FullBank$age))/(max(FullBank$age)-min(FullBank$age))
FullBank$balance<-(FullBank$balance-min(FullBank$balance))/(max(FullBank$balance)-min(FullBank$balance))
FullBank$duration<-(FullBank$duration-min(FullBank$duration))/(max(FullBank$duration)-min(FullBank$duration))
FullBank$day<-(FullBank$day-min(FullBank$day))/(max(FullBank$day)-min(FullBank$day))
FullBank$campaign<-(FullBank$campaign-min(FullBank$campaign))/(max(FullBank$campaign)-min(FullBank$campaign))
FullBank$previous<-(FullBank$previous-min(FullBank$previous))/(max(FullBank$previous)-min(FullBank$previous))



summary(FullBank)
#attach the training dataset for ease of writing and maintaining code
attach(FullBank)
#install the library party for decision tree
install.packages("party")
#invoke the needed library
library("party")
#set random seed to make the sampling reproducible
set.seed(123)
smp_size<-floor(.9 * nrow(FullBank))
train_ind<-sample(seq_len(nrow(FullBank)), size=smp_size)
train <-FullBank[train_ind, ]
test <- FullBank[-train_ind, ]
#check the ratio of train set
nrow(train)/nrow(FullBank)

#build decision tree model using ctree function
#y is target attribute
DT<-ctree(y ~ age + job + marital + education + default + balance + housing + loan + contact + day + month + duration + campaign + pcontact + previous + poutcome, data=FullBank)
#DT<-ctree(y ~ balance, data=FullBank)

#examine the properties of the decision tree model created
DT
#Apply the decision tree model to the prediction dataset to generate the value of
#target attribute in prediction dataset
R_DT<-predict(DT, test)
#view the predictions
R_DT
#view summary information
summary(R_DT)
write.csv(R_DT, file="R_DT.csv")
#invoke library e1071
library(e1071)
#build a NB model using naiveBayes function and including all attributes
NB<-naiveBayes(y ~., data=FullBank)
#view the NB model generated and conditional probabilities
NB
#apply the model for prediction and store it in R_NB
R_NB<-predict(NB, test)
#view the prediction result
R_NB
#show the summary statistics of R_NB
summary(R_NB)
write.csv(R_NB, file="R_NB.csv")
#develop a logistic regression model using glm function
LR<-glm(y ~ .,family="binomial", data=FullBank)
#view the logistic regression model
summary(LR)
#apply the model for prediction and store in R_LRP
R_LRP<-predict(LR, test, type="response")
#convert probabilities to prediction class and then convert it to a factor
R_LR<-as.factor(ifelse(R_LRP> 0.5, "yes", "no"))
summary(R_LR)
write.csv(R_LR, file="R_LR.csv")
#invoke library nnet 
library(nnet)
#set seed
set.seed(1000)


#build a neural network model using y as target attribute and other attributes as predictor attributes
#size parameter indicates the number of nodes we wish to use the hidden layer
#the maxit parameter indicates the maximum iterations
NN<-nnet(y ~., data=FullBank, size=4, maxit=10000)
#apply the model for prediction and store it in R_NNP
R_NNP<-predict(NN, test)
#convert probabilities to prediction class and then convert to a factor
R_NN<-as.factor(ifelse(R_NNP>0.5, "yes", "no"))
#show summary statistics of R_NN
summary(R_NN)
write.csv(R_NN, file="R_NN.csv")
#convert all the predictions to vector and then combine all of them using rbind
R_Predict<-rbind(as.vector(R_DT), as.vector(R_NB), as.vector(R_LR), as.vector(R_NN))
#Transpose the combination and then convert it to a data frame
R_DF<-as.data.frame(t(R_Predict))
#Rename the columns
colnames (R_DF) <-c("R_DT", "R_NB", "R_LR", "R_NN")
#write R_DF to a csv file
write.csv(R_DF, "R_DF.csv")

library("caret")
#confusion matrix for DT
table(R_DT, test[["y"]])
#alternatively we can use confusion matrixfunction to get more details
#check the type of both R_LR and y
typeof(R_DT)
typeof(test[["y"]])
#The confusionMatrix function requires factors with the same level
DTp_class<-as.factor(R_DT)
confusionMatrix(DTp_class, as.factor(test[["y"]]))
confusionMatrix(DTp_class, as.factor(test[["y"]]), positive="yes")

#confusion matrix for NB
table(R_NB, test[["y"]])
#alternatively we can use confusion matrixfunction to get more details
#check the type of both R_LR and y
typeof(R_NB)
typeof(test[["y"]])
#The confusionMatrix function requires factors with the same level
NBp_class<-as.factor(R_NB)
confusionMatrix(NBp_class, as.factor(test[["y"]]))
confusionMatrix(NBp_class, as.factor(test[["y"]]), positive="yes")

#confusion matrix for LR
#generate a simple confusion matrix using the table function
table(R_LR, test[["y"]])
#alternatively we can use confusion matrixfunction to get more details
#check the type of both R_LR and y
typeof(R_LR)
typeof(test[["y"]])
#The confusionMatrix function requires factors with the same level
LRp_class<-as.factor(R_LR)
confusionMatrix(LRp_class, as.factor(test[["y"]]))
confusionMatrix(LRp_class, as.factor(test[["y"]]), positive="yes")

#confusion matrix for NN
table(R_NN, test[["y"]])
#alternatively we can use confusion matrixfunction to get more details
#check the type of both R_LR and y
typeof(R_NN)
typeof(test[["y"]])
#The confusionMatrix function requires factors with the same level
NNp_class<-as.factor(R_NN)
confusionMatrix(NNp_class, as.factor(test[["y"]]))
confusionMatrix(NNp_class, as.factor(test[["y"]]), positive="yes")

install.packages('NeuralNetTools')
library(NeuralNetTools)
#plot the neural network model
plotnet(NN)
