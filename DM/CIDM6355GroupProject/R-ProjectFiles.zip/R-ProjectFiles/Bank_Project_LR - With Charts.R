# define and choose the dataset 
bankdatafull <- read.csv(choose.files(), header = T)
#bankdatafull_ <- read.csv(choose.files(), header = T)
#check structure of datasets
str(bankdatafull)
#need to convert char to factor
bankdatafull[sapply(bankdatafull, is.character)] <- lapply(bankdatafull [sapply(bankdatafull, is.character)], as.factor)
#view structure again, verify factor instead of character 
str(bankdatafull)
summary(bankdatafull)
#attach the training dataset for ease of writing and maintaining code
attach(bankdatafull)
#set random seed to make the sampling reproducaible
set.seed(123)
smp_size<-floor(.9 * nrow(bankdatafull))
train_ind<-sample(seq_len(nrow(bankdatafull)), size=smp_size)
train <-bankdatafull[train_ind, ]
test <- bankdatafull[-train_ind, ]

#check the ratio of train set
nrow(train)/nrow(bankdatafull)
# install and load the required libraries
install.packages("e1071")
install.packages("caret")
install.packages("dplyr")
install.packages("reshape2")
# installing library dplyr,caret,dplyr,reshape2
library("e1071")
library("caret")
library("dplyr")
library("reshape2")


# building a logistic regression model using the train set
bankdatafullLR <- glm(y ~. , family = "binomial", bankdatafull)

#view the logistic regression model
summary(bankdatafullLR)

# apply the model to the test set; probabilities are generated 
BankLP <- predict(bankdatafullLR, test, type = "response")

#convert probabilities to prediction class and then convert it to a factor
Bank_LRP<-as.factor(ifelse(BankLP> 0.5, "yes", "no"))

#view the new logistic regression model with > 0.5
summary(Bank_LRP)

# confusion matrix for LR
# generating a sample table for confusion matrix using a tble function
table(Bank_LRP, test[["y"]])

# using confusion matrix function as an alternatively to get more details
# checking  for the type of both Bank_LRP and y before running the confusion matrix
# Because confusionMatrix function requires factors with the same level

typeof(Bank_LRP)
typeof(test[["y"]])

# running the confusion Matrix since the attribute has the same factors level

BankLRP_class<-as.factor(Bank_LRP)

# building the confusion Matrix 
confusionMatrix(BankLRP_class, as.factor(test[["y"]]))
confusionMatrix(BankLRP_class, as.factor(test[["y"]]), positive="yes")

##***************************************************************************
## Building the charts with the result set

# using pie chart to plot # of Term Deposit Subscription
# import library chart plotrix and install RColorBrewer
library(plotrix)
install.packages("RColorBrewer")

BankData <- table(bankdatafull$y)
# create a legend value and assign Yes and No Value to it 

lgd <- c("Yes", "No")

# getting the percentatgae for the BankData
grpcht<- round(BankData/sum(BankData)*100)

# adding percent to the label of the chart
chart_lable <- paste(grpcht, "%", sep = "")


# plotting the pie chart using 3D pie chart

pie3D(BankData,labels=chart_lable, cex=0.7, col =c("pink","lightblue"), main= "Percentage of Bank Term Deposit Subscriptions By Customers")

#  adding the legend and label
legend("topright", fill =c("lightblue", "pink"), legend=lgd)

#****************************************************************
#working bar chart to compare term deposit by education level
# Loding and installing needed libraries 

library(ggplot2)
install.packages("ggthemes")
install.packages("ggeasy")
library(ggthemes)
library(scales)
library(dplyr)

dt <- bankdatafull%>%
  dplyr::group_by(education, y)%>%
  dplyr::tally()%>%
  dplyr::mutate(percent=n/sum(n))
pl1 <-ggplot(data = dt, aes(x=education, y = n, fill = y))
pl2 <- pl1 + geom_bar(stat = "identity") + scale_fill_manual(values=c("pink","lightblue"))
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "white")
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "white")
pl3
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "Black")
pl3
pl4 <- pl3 + labs (title = "Percentage of Bank Term Deposit Subscription By Education Level")
pl4
ggeasy::easy_center_title()
pl5 <- pl4 + theme_update(plot.title = element_text(hjust = 0.5))
pl5

pl5 <- pl4 + theme_update(plot.title = element_text(hjust = 0.5))
pl5
                 
##*************************************************************
##*bar char to compare term deposit subscription over y
library(ggplot2)
install.packages("ggthemes")
install.packages("ggeasy")
library(ggthemes)
library(scales)
library(dplyr)

dt <- bankdatafull%>%
  dplyr::group_by(housing, y)%>%
  dplyr::tally()%>%
  dplyr::mutate(percent=n/sum(n))
pl1 <-ggplot(data = dt, aes(x=housing, y = n, fill = y))
pl2 <- pl1 + geom_bar(stat = "identity") + scale_fill_manual(values=c("#d4b8b8","#a1ae9d"))
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "white")
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "white")
pl3
pl3 <- pl2 + geom_text(aes(label = paste0(sprintf("%1.1f", percent *100), "%")), position = position_stack(vjust=0.5), colour = "Black")
pl3
pl4 <- pl3 + labs (title = "Percentage of Bank Term Deposit Subscription By Housing")
pl4
ggeasy::easy_center_title()
pl5 <- pl4 + theme_update(plot.title = element_text(hjust = 0.5))
pl5
#**************************************************************
# 
library(dplyr)
library(ggplot2)
library(tidyr)

dt %>% mutate_if(is.integer,as.numeric)
  select_if(is.numeric()) %>%
  pivot_longer(cols=c(1:16), names_to = "variable", values_to = "value") %>%
  ggplot(aes(y=value))+geom_boxplot()+facet_wrap(~variable,scales = "free")
dataset %>% mutate_if(is.character,as.numeric)
