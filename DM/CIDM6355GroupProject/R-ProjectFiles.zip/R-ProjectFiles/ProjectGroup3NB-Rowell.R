# define and choose Training and Prediction datasets
ProjectTrain<-read.csv(file.choose(),header=T, stringsAsFactors = TRUE)
ProjectPredict<-read.csv(file.choose(),header=T, stringsAsFactors = TRUE)
# view column names and dimensions of the training dataset (please note that the dash is changed to dot in R)
names(ProjectTrain)
dim(ProjectTrain)
# view the summary statistics of the training dataset
summary(ProjectTrain)
# view the summary statistics of the predict dataset
summary(ProjectPredict)
# install package e1071
install.packages("e1071")
# invoke the library e1071
library(e1071)
# build a NB model using naiveBayes function and including all attributes
ProjectNB<-naiveBayes(y ~., data=ProjectTrain)
# view the NB model generated and conditional probabilities
ProjectNB
# Apply the NB model to the prediction dataset
Projectscore<-predict(ProjectNB,ProjectPredict)
# view the prediction result
Projectscore
summary(Projectscore)
# the following three lines help us write the prediction value of open_account to the prediction dataset
score<-data.frame(Projectscore)
ProjectPredict$y<-score$Projectscore
summary(ProjectPredict)
# Combine predictions with prediction dataset into one single data frame
ProjectPrediction<-data.frame(Projectscore,ProjectPredict)
summary(ProjectPrediction)
write.csv(Projectscore, file = "ProjectscoreNB-R.csv")
